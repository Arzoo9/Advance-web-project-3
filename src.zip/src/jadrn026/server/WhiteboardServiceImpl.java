package jadrn026.server;

import jadrn026.client.WhiteboardService;
import jadrn026.shared.FieldVerifier;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class WhiteboardServiceImpl extends RemoteServiceServlet implements WhiteboardService {
	public String validateLogin(String input) throws IllegalArgumentException {
		if(input.equalsIgnoreCase("sp2018")) return "OK";
		return "INVALID";
	}
	public String save(String contents) throws IllegalArgumentException {
		String path = getServletContext().getRealPath("/");
		System.out.println(path);
		String filename = path+"/data.txt";
		String answer = "";
		String line;
		try{
			PrintWriter out = new PrintWriter(
					new FileWriter(filename));
			contents = contents.replace("\r\n|\n","<br />");
			out.print(contents);
			out.close();	
		}
		catch(Exception e){
			return "ERROR, failed to save file";
		}
		return "File successfully saved";

	}

	public String load() throws IllegalArgumentException {
		String path = getServletContext().getRealPath("/");
		String filename = path+"/data.txt";
		System.out.println(path);
		String answer = "";
		String line;
		try{
			BufferedReader in = new BufferedReader(
					new FileReader(filename));
			while((line = in.readLine()) != null)
				answer += line;
			in.close();
		}
		catch(Exception e){
			return "Failed to read file.";
		}
		return answer;
	}
}
