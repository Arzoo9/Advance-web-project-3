package jadrn026.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface WhiteboardServiceAsync {
	void validateLogin(String input, AsyncCallback<String> callback) throws IllegalArgumentException;
	void save(String contents, AsyncCallback<String> callback)
			throws IllegalArgumentException;
	void load(AsyncCallback<String> callback)
			throws IllegalArgumentException;
}
