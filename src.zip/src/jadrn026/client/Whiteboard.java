package jadrn026.client;

import jadrn026.shared.FieldVerifier;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RichTextArea;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class Whiteboard implements EntryPoint {
	private final WhiteboardServiceAsync whiteboardService = GWT.create(WhiteboardService.class);

	private HTML status,boardStatus;
	private RichTextArea board;
	public void onModuleLoad() {
		status = new HTML("");
		boardStatus = new HTML("");
		buildLogin();
	}
	private void buildLogin() {
		FlowPanel loginBox = new FlowPanel();
		final PasswordTextBox passwrodTextBox = new PasswordTextBox();	
		passwrodTextBox.setStyleName("passwrodTextBox");
		loginBox.add(new HTML("Enter your password"));
		FlowPanel buttonPanel = new FlowPanel();
		buttonPanel.setStyleName("buttonPanel");
		Button loginButton = new Button("Login");
		Button clearButton = new Button("Clear");
		loginButton.setStyleName("LoginButton");
		clearButton.setStyleName("LoginButton");
		clearButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				status.setText("");
				passwrodTextBox.setFocus(true);
				passwrodTextBox.setText("");
			}
		});
		
		loginButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				status.setText(passwrodTextBox.getText());
				validateLogin(passwrodTextBox.getText());
				passwrodTextBox.setFocus(true);
			}
		});
		
		buttonPanel.add(loginButton);
		buttonPanel.add(clearButton);
		loginBox.add(passwrodTextBox);
		loginBox.add(buttonPanel);
		loginBox.add(status);
		loginBox.add(new HTML("<h2>Code By Arzoo Patel, Account: Jadrn026</h2>"));
		loginBox.setStyleName("LoginBox");
		RootPanel.get().add(new HTML("<h1>Online Whiteboard</h1>"));
		RootPanel.get().add(loginBox);
		passwrodTextBox.setFocus(true);
	}
	
	private void validateLogin(String password) {
		AsyncCallback<String> callback = new AsyncCallback<String>() {
			@Override
			public void onFailure(Throwable caught) {
				status.setText("Sorry, Something went wrong.");
			}
			
			@Override
			public void onSuccess(String result) {
				String answer = (String)result;
				if(answer.equals("OK")) {
					status.setText("");
					buildMainPanel();
				}else {
					status.setText("Error, Password is incorrect!");
				}
			}
		};
		whiteboardService.validateLogin(password, callback);
	}
	
	private void buildMainPanel() {
		FlowPanel boardPanel = new FlowPanel();
		boardPanel.add(new HTML("<h1>Online whiteboard</h1>"));
		boardPanel.add(getButtonPanel());
		board = new RichTextArea();
		board.setStyleName("whiteboard");
		boardStatus.setStyleName("boardStatus");
		boardPanel.add(board);
		boardPanel.add(boardStatus);
		RootPanel.get().clear();
		RootPanel.get().add(boardPanel);
		board.setFocus(true);
	}
	private FlowPanel getButtonPanel() {
		FlowPanel boardButton = new FlowPanel();
		Button clear = new Button("Clear");
		Button save =  new Button("Save");
		Button load = new Button("Load");
		clear.setStyleName("boardBtns");
		save.setStyleName("boardBtns");
		load.setStyleName("boardBtns");
		clear.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				board.setText("");
				boardStatus.setText("");
			}
		});
		save.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				savePanel();		
			}
		});
		load.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				loadPanel();				
			}
		});
		boardButton.setStyleName("boardButton");
		boardButton.add(save);
		boardButton.add(load);
		boardButton.add(clear);
		return boardButton;
	}
	
	private void savePanel(){
		AsyncCallback callback = new AsyncCallback(){
			public void onSuccess(Object results){
				boardStatus.setText((String)results);
			}
			public void onFailure(Throwable error){ }
		};
		whiteboardService.save(board.getHTML(), callback);
	}

	private void loadPanel(){
		AsyncCallback callback = new AsyncCallback(){
			public void onSuccess(Object results){
				board.setHTML((String)results);
			}
			public void onFailure(Throwable error){ }
		};
		whiteboardService.load(callback);
	}
}
